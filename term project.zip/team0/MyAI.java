package team0;

import game.AI;
import game.Board;
import game.Board.ControlKeys;
import game.Shape;
import game.Shape.Tetrominoes;

public class MyAI extends AI {
    
    // default constructor must be public
    public MyAI() {
        super();
    };
    
    int rightEmpty(int y) {        
        for (int x=Board.WIDTH; x-->0;) {
            if (shapeAt(x, y) == Tetrominoes.EMPTY) return x;
        }
        return -1;
    }    
    
    int leftEmpty(int y) {
        for (int x=0; x<Board.WIDTH; x++) {
            if (shapeAt(x, y) == Tetrominoes.EMPTY) return x;
        }
        return Board.WIDTH;
    }
    
    @Override
    protected ControlKeys command() {
        ControlKeys key = ControlKeys.SPACE;
        Shape curPiece = getCurPiece();
        
        if (curPiece.getShape() == Tetrominoes.ISHAPE) {
            int targetX = Board.WIDTH - 1;
            for (int y=0; y<Board.HEIGHT; y++) {                
                if (rightEmpty(y) >= 4) {
                    targetX = rightEmpty(y);    
                    break;
                }
            }
            if (shapeAt(4, 18) != Tetrominoes.EMPTY) {
                key = ControlKeys.DEL;
            } else if (getCurX() < targetX) {
                key = ControlKeys.RIGHT;
            } else if (getCurX() > targetX) {
                key = ControlKeys.LEFT;
            }
        } else if (curPiece.getShape() == Tetrominoes.SQUARE) {
            int targetX = 0;
            for (int y=0; y<Board.HEIGHT; y++) {                
                if (leftEmpty(y) < 4) {
                    targetX = leftEmpty(y);
                    break;
                }
            }            
            if (shapeAt(3, 18) != Tetrominoes.EMPTY) {        
                key = ControlKeys.DEL;
            } else if (getCurX() > targetX) {            
                key = ControlKeys.LEFT;
            }            
        } else {
            key = ControlKeys.DEL;
        }
        return key;
    }
}
